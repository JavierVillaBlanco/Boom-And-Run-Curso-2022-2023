//import { cUser } from "./cliente.js";
import { rUsers } from "./cliente.js";
export class load extends Phaser.Scene
{
    conectado = false
    uName 
    a
    constructor()
    {
        super({key: 'load'})
    }
    init(data){
       this.conectado = data.sesion;
       this.uName = data.uName;
       this.a = data.BMGT;
    }
    preload(){
        this.load.image('loading', 'assets/UI/fondo.jpg');
        this.load.image('JBT', 'assets/UI/jugar.png');
        this.load.image('TBT', 'assets/UI/tutorial.png');
        
        this.load.image('OBT', 'assets/UI/creditos.png');
        this.load.image('title', 'assets/UI/title.png');
        this.load.image('SBT', 'assets/UI/salir.png');
        this.load.image('BBT', 'assets/UI/back.png');
        
        this.load.audio('BGMM', 'assets/music/menu.mp3');

    }
    create(){
        var BGM =this.sound.add('BGMM');
       
        BGM.volume = 0.3;
        BGM.loop = true;
        BGM.play();
        this.add.image(324, 228, 'loading');
        this.add.image(324, 100, 'title');
        
        let playButton2 = this.add.image(324+3, 228+40, 'TBT').setScale(0.5);
        let playButton3 = this.add.image(324, 228+75, 'OBT').setScale(0.5);
        let playButton4 = this.add.image(324, 228+75+40, 'SBT').setScale(0.7);
       
        
        playButton2.setInteractive();
        playButton3.setInteractive();
        playButton4.setInteractive();
        
       
        playButton2.on('pointerup', () =>{this.scene.start('tuto2',{BGMT:BGM})})
        playButton3.on('pointerup', () =>{this.scene.start('credit',{BGMT:BGM})})
        playButton4.on('pointerup', () =>{BGM.stop();this.scene.start('load',{sesion:false,uName:'Guest'})})

        let playButton = this.add.image(324, 228, 'JBT').setScale(0.7);
            playButton.setInteractive();
            playButton.on('pointerup', () =>{this.scene.start('CharSelect',{BGMT:BGM,uName:'Guest',sesion:this.conectado})})
        
        
        
    }
    update(){
        
    }
}