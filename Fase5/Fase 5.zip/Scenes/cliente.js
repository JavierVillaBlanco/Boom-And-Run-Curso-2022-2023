var enlace = "http://localhost:8080"

export function rUsers() {
    $.ajax({
        url: enlace + "/users"
    }).done(function (items) {
       // console.log(items);
       
    })
}

export function cUser(a)
{
    $.ajax({
		method: "POST",
		url: enlace + "/users",
		data: JSON.stringify(a),
		processData: false,
		headers: {
			"Content-type": "application/json"
		}
	}).done(function(data, textStatus, jqXHR) {
		console.log("Bien")
        console.log("Item created: " + JSON.stringify(a));
		console.log(textStatus+" "+jqXHR.statusCode());
	}).fail(function(data, textStatus, jqXHR) {
		console.log(textStatus+" "+jqXHR.statusCode());
		console.log("Mal")
	});
}
export function registrar(a)
{
	var correcto = false;
    $.ajax({
		method: "POST",
		url: enlace + "/registro",
		async:false,
		data: JSON.stringify(a),
		processData: false,
		headers: {
			"Content-type": "application/json"
		}
	}).done(function(data, textStatus, jqXHR) {
		console.log("Bien")
        //console.log("Registro " + JSON.stringify(a));
		correcto = true
		//console.log(textStatus+" "+jqXHR.statusCode());
	}).fail(function(data, textStatus, jqXHR) {
		//console.log(textStatus+" "+jqXHR.statusCode());
		console.log("Mal")
		correcto = false;
	});
	return correcto;
}
export function logeo(a)
{
	var correcto = false;
    $.ajax({
		method: "POST",
		url: enlace + "/login",
		async:false,
		data: JSON.stringify(a),
		processData: false,
		headers: {
			"Content-type": "application/json"
		}
	}).done(function(data, textStatus, jqXHR) {
		console.log("Bien")
        //console.log("Log " + JSON.stringify(a));
		//console.log(textStatus+" "+jqXHR.statusCode());
		correcto = true
	}).fail(function(data, textStatus, jqXHR) {
		//console.log(textStatus+" "+jqXHR.statusCode());
		console.log("Mal")
		correcto = false;
	});
	return correcto;
}

export function score(a)
{
	var correcto = false;
    $.ajax({
		method: "PUT",
		url: enlace + "/score",
		async:false,
		data: JSON.stringify(a),
		processData: false,
		headers: {
			"Content-type": "application/json"
		}
	}).done(function(data, textStatus, jqXHR) {
		console.log("Bien")
        
		console.log(textStatus+" "+jqXHR.statusCode());
		correcto = true
	}).fail(function(data, textStatus, jqXHR) {
		console.log(textStatus+" "+jqXHR.statusCode());
		console.log("Mal")
		correcto = false;
	});
	return correcto;
}

export function hScore() {
    $.ajax({
        url: enlace + "/score"
    }).done(function (items) {
        items.sort((a,b)=>(a.hPunt >b.hPunt) ? -1:1)
		//console.log(items);

       
    })
}

