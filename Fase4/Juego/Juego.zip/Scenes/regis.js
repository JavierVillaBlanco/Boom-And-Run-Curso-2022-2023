//import { cUser } from "./cliente.js";
import { registrar } from "./cliente.js";
var errorR
export class regis extends Phaser.Scene 
{  
    correcto = false
    constructor()
    {
        super({key: 'regis'})
    }
    init()
    {
        
    }
    preload()
    {
       
        this.load.image('backSesion', 'assets/fondoTuto.png');
        this.load.html('nameform', 'assets/loginform2.html');
        this.load.image('regT','assets/UI/regisT.png');
        this.load.image('regE','assets/UI/errorRegis.png');
        
        
    }
    create()
    {
        
        this.add.image(324, 228, 'backSesion');
        this.add.image(324, 35, 'regT').setScale(0.6);
        errorR =  this.physics.add.sprite(800, 800, 'regE');
        let playButton = this.add.image(60, 10+15, 'backT2').setScale(0.4);
        
        playButton.setInteractive();
        playButton.on('pointerup', () =>{this.scene.start('sesion')})
        
        var element = this.add.dom(324, 228).createFromCache('nameform');
        
        element.setPerspective(800);

        element.addListener('click');

        element.on('click', function (event) {

            if (event.target.name === 'loginButton')
            {
                var inputUsername = this.getChildByName('username');
                var inputPassword = this.getChildByName('password');
               
                //  Have they entered anything?
                if (inputUsername.value !== '' && inputPassword.value !== '')
                {
                    if(registrar({uName:inputUsername.value,pw:inputPassword.value})){
                        //  Turn off the click events
                        console.log('hey')
                        this.removeListener('click');

                   //  Tween the login form out
                        this.scene.tweens.add({ targets: element.rotate3d, x: 1, w: 90, duration: 3000, ease: 'Power3' });

                        this.scene.tweens.add({ targets: element, scaleX: 2, scaleY: 2, y: 700, duration: 3000, ease: 'Power3',
                       onComplete: function ()
                       {
                           element.setVisible(false);
                           
                       }
                   });

                   //  Populate the text with whatever they typed in as the username!
                   this.scene.correcto = true
                   }
                   else
                   {
                        //registro fallido
                        
                        showErrorR()
                   }
                  
                }
                else
                {
                    //  Flash the prompt
                    this.scene.tweens.add({ targets: text, alpha: 0.1, duration: 200, ease: 'Power3', yoyo: true });
                }
            }

        });
    
        this.tweens.add({
            targets: element,
            y: 240,
            duration: 3000,
            ease: 'Power3'
        });
        
    }
    update(){
        
        if (this.correcto){
            clearErrorR();
            this.scene.start('sesion')
        }
    }
    
}

function showErrorR() {
    errorR.x = 324;
    errorR.y = 370;
}
function clearErrorR() {
    errorR.x = 800;
    errorR.y = 800;
}