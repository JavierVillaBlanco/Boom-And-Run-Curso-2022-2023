
import {fase1} from './Scenes/Cjava.js';
import {fase2} from './Scenes/Cjava2.js';
import {fase3} from './Scenes/Cjava3.js';
import {Ofase1} from './Scenes/OCjava.js';
import {Ofase2} from './Scenes/OCjava2.js';
import {Ofase3} from './Scenes/OCjava3.js';
import {LP1} from './Scenes/LP1.js';
import {LP2} from './Scenes/LP2.js';
import {DRAW} from './Scenes/DRAW.js';
import {load} from './Scenes/load.js';
import {tuto} from './Scenes/tuto.js';
import {CharSelect} from './Scenes/CharSelect.js';
import {OCharSelect} from './Scenes/OCharSelect.js';
import {Searching} from './Scenes/Searching.js';
import {sesion} from './Scenes/sesion.js';
import { regis } from './Scenes/regis.js';
import { scores } from './Scenes/scores.js';
import { desinc } from './Scenes/desinc.js';

import {tuto2} from './Scenes/tuto2.js';
import {tuto3} from './Scenes/tuto3.js';
import {credit} from './Scenes/credit.js';

var config = {
    type: Phaser.AUTO,
    width: 648,
    height: 456,
    parent: 'dick',
    dom:{createContainer: true},
    //Fisicas
    physics: {
        default: 'arcade',
        arcade: {
            
            debug: false
        }
    },
    //Escenas
    scene:[load,CharSelect,fase1,fase2,fase3,LP1,LP2,DRAW,tuto,sesion,regis,scores,OCharSelect,Searching,Ofase1,Ofase3,desinc,tuto2,tuto3,credit]
    
};
var game = new Phaser.Game(config);