import { logeo } from "./cliente.js";
var errorL
export class sesion extends Phaser.Scene 
{  
    correcto = false
    username
    BGMC; 
    constructor()
    {
        super({key: 'sesion'})
    }
    init(data)
    {
         this.BGMC = data.BGMT;
         this.correcto = data.sesion
         this.username = null
    }
    preload()
    {
       
        this.load.image('backSesion', 'assets/fondoTuto.png');
        this.load.image('log2', 'assets/UI/Login2.png');
        this.load.image('errorLog', 'assets/UI/errorSesion.png');
        this.load.image('reg','assets/UI/regis.png')
        this.load.html('nameform', 'assets/loginform2.html');
        this.load.image('backT2','assets/UI/back2.png')
        
    }
    create()
    {
        this.BGMC.stop();
        this.add.image(324, 228, 'backSesion');
        this.add.image(324, 35, 'log2').setScale(0.6);
        errorL =  this.physics.add.sprite(800, 800, 'errorLog');
        let playButton = this.add.image(60, 10+15, 'backT2').setScale(0.4);
        let playButton2 = this.add.image(515,430, 'reg').setScale(0.5);
        playButton.setInteractive();
        playButton.on('pointerup', () =>{this.scene.start('load')})
        playButton2.setInteractive();
        playButton2.on('pointerup', () =>{this.scene.start('regis')})
        //var text = this.add.text(10, 10, 'Please login to play', { color: 'white', fontFamily: 'Arial', fontSize: '32px '});
        var element = this.add.dom(324, 228).createFromCache('nameform');
        
        element.setPerspective(800);

        element.addListener('click');

        element.on('click', function (event) {

            if (event.target.name === 'loginButton')
            {
                var inputUsername = this.getChildByName('username');
                var inputPassword = this.getChildByName('password');

                //  Have they entered anything?
                if (inputUsername.value !== '' && inputPassword.value !== '')
                {
                    if(logeo({uName:inputUsername.value,pw:inputPassword.value})){
                         //  Turn off the click events
                    console.log('hey')
                    this.removeListener('click');

                    //  Tween the login form out
                    this.scene.tweens.add({ targets: element.rotate3d, x: 1, w: 90, duration: 3000, ease: 'Power3' });

                    this.scene.tweens.add({ targets: element, scaleX: 2, scaleY: 2, y: 700, duration: 3000, ease: 'Power3',
                        onComplete: function ()
                        {
                            element.setVisible(false);
                            
                        }
                    });
                        this.scene.username = inputUsername.value
                        this.scene.correcto = true
                         
                    //  Populate the text with whatever they typed in as the username!
                    
                    
                    }
                    else
                    {
                        //login fallido
                        showError();
                        
                    }
                   
                }
                else
                {
                    //  Flash the prompt
                    this.scene.tweens.add({ targets: text, alpha: 0.1, duration: 200, ease: 'Power3', yoyo: true });
                }
            }

        });
    
        this.tweens.add({
            targets: element,
            y: 240,
            duration: 3000,
            ease: 'Power3'
        });
        
    }
    update(){
        if (this.correcto)
        {
            clearError()
            this.scene.start('load',{sesion:true,uName:this.username})
        }
    }
    
}
function showError() {
        errorL.x = 324;
        errorL.y = 370;
}
function clearError() {
    errorL.x = 800;
    errorL.y = 800;
}