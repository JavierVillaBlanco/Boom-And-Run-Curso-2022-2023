var GPMTHC
export class desinc extends Phaser.Scene
{
    conectado = false
    uName 
    a
    constructor()
    {
        super({key: 'desinc'})
    }
    init(data){
        
        GPMTHC = data.GPMTHC;
        this.conectado = data.sesion;
        this.uName = data.uName;
        
    }
    preload(){
        this.load.image('backTuto', 'assets/fondoTuto.png');
        this.load.image('conex','assets/UI/CONEXION.png');
        this.load.audio('HMTH', 'assets/music/japon.mp3');
        

    }
    create(){
        GPMTHC.stop();
        this.add.image(324, 228, 'backTuto');
        this.add.image(324,228,'conex').setScale(0.7);
        let playButton = this.add.image(608-15, 10+15, 'BBT').setScale(0.5);
        playButton.setInteractive();
        playButton.on('pointerup', () =>{this.scene.start('load',{uName:this.username,sesion:this.conectado})})

       
        
        
    }
    update(){
        
        
    }
}