var high
var high2
var cursors;
var keySpace;
var keyA;
var keyW;
var keyS;
var keyD;
var keyEnter;
var BGMC;
export class tuto extends Phaser.Scene
{
    constructor()
    {
        super({key: 'tuto'})
    }
    init(data){
        //BGMC = data.BGMT;
    }
    preload(){
        this.load.image('backTuto', 'assets/fondoTuto.png');
        this.load.image('MT', 'assets/UI/MOVIMIENTO.png');
        this.load.image('BT', 'assets/UI/BOMBA.png');
        this.load.image('JBT', 'assets/UI/jugar.png');
        this.load.image('TBT', 'assets/UI/tutorial.png');
        this.load.image('OBT', 'assets/UI/opciones.png');
        this.load.image('title', 'assets/UI/title.png');
        this.load.image('SBT', 'assets/UI/salir.png');
        this.load.image('KUp', 'assets/UI/Teclas/up.png');
        this.load.image('KDwn', 'assets/UI/Teclas/down.png');
        this.load.image('KL', 'assets/UI/Teclas/left.png');
        this.load.image('KR', 'assets/UI/Teclas/right.png');
        this.load.image('KEntr', 'assets/UI/Teclas/enter.png');
        this.load.image('Kspace', 'assets/UI/Teclas/space.png');
        this.load.image('Kw', 'assets/UI/Teclas/w.png');
        this.load.image('Ka', 'assets/UI/Teclas/a.png');
        this.load.image('Ks', 'assets/UI/Teclas/s.png');
        this.load.image('Kd', 'assets/UI/Teclas/d.png');
        this.load.image('KHigh', 'assets/UI/Teclas/key1.png');
        this.load.image('puntP1Txt', 'assets/UI/puntP1.png');
        this.load.image('puntP2Txt', 'assets/UI/puntP2.png');
        this.load.audio('BGMM', 'assets/music/menu.mp3');

    }
    create(){
        /*var BGM =this.sound.add('BGMM');
        BGM.volume = 0.3;
        BGM.loop = true;
        BGM.play();*/
        //BGMC.stop();
        this.add.image(324, 228, 'backTuto');
        this.add.image(324, 30, 'MT').setScale(0.7);
        this.add.image(324, 245, 'BT').setScale(0.5);
        this.add.image(648/3, 120, 'Kw');
        this.add.image(648/3, 120+47, 'Ks');
        this.add.image((648/3)+45, 120+47, 'Kd');
        this.add.image((648/3)-45, 120+47, 'Ka');
        this.add.image(648/3, 245, 'Kspace');

        this.add.image(2*(648/3), 120, 'KUp');
        this.add.image(2*(648/3), 120+47, 'KDwn');
        this.add.image(2*(648/3)-45, 120+47, 'KL');
        this.add.image(2*(648/3)+45, 120+47, 'KR');
        this.add.image(2*(648/3), 245, 'KEntr');
        
        this.add.image(648/3, 70, 'puntP1Txt').setScale(0.6);
        this.add.image(2*(648/3), 70, 'puntP2Txt').setScale(0.6);
        this.add.image(800, 800, 'KHigh');
        high =  this.physics.add.sprite(800, 800, 'KHigh');
        high2 =  this.physics.add.sprite(800, 800, 'KHigh');
        cursors = this.input.keyboard.createCursorKeys();
        keySpace = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE); 
        keyA = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
        keyD = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);
        keyS = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
        keyW = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
        keyEnter = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);

        let playButton = this.add.image(324, 3.5*(228/2), 'JBT').setScale(0.7);
        playButton.setInteractive();
        playButton.on('pointerup', ()=>{this.scene.start('load')})

        let playButton2 = this.add.image(60, 50, 'backT').setScale(0.5);
        playButton2.setInteractive();
        playButton2.on('pointerup', ()=>{this.scene.start('tuto3')})

        
        
                
    }
    update(){
        if (keyA.isDown)
    {
       highlight((648/3)-45, 120+47)
    }
    else if (keyD.isDown)
    {
        highlight((648/3)+45, 120+47)
    }
    else if (keyW.isDown)
    {
        highlight(648/3, 120)
    }
    else if (keyS.isDown)
    {
        highlight(648/3, 120+47)
    }
    else if(keySpace.isDown)
    {
        highlight(648/3, 245)
    }
    else
    {
        highlight(800, 800)
    }

    if (cursors.up.isDown)
    {
       highlight2(2*(648/3), 120)
    }
    else if (cursors.down.isDown)
    {
        highlight2(2*(648/3), 120+47)
    }
    else if (cursors.left.isDown)
    {
        highlight2(2*(648/3)-45, 120+47)
    }
    else if (cursors.right.isDown)
    {
        highlight2(2*(648/3)+45, 120+47)
    }
    else if(keyEnter.isDown)
    {
        highlight2(2*(648/3), 245)
    }
    else
    {
        highlight2(800, 800)
    }
    }
}
function highlight(posX,posY){
    high.x = posX
    high.y = posY
}

function highlight2(posX,posY){
    high2.x = posX
    high2.y = posY
}