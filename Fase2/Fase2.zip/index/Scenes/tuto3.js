var BGMC;
export class tuto3 extends Phaser.Scene
{
    constructor()
    {
        super({key: 'tuto3'})
    }
    init(data){
        BGMC = data.BGMT;
    }
    preload(){
        this.load.image('backTuto', 'assets/fondoTuto.png');
        this.load.image('backTuto2', 'assets/fondoTuto2.png');
        this.load.image('backTuto3', 'assets/fondoTuto3.png');
        this.load.image('PuntT', 'assets/UI/Puntuacion.png');
        this.load.image('WinT', 'assets/UI/GANADOR.png');
        this.load.image('backT','assets/UI/back2.png')
        this.load.image('nextT','assets/UI/next2.png')
        this.load.audio('BGMM', 'assets/music/menu.mp3');

    }
    create(){
        if (BGMC != null){BGMC.stop();}
        
        this.add.image(324, 228, 'backTuto3');
        this.add.image(324, 42, 'WinT').setScale(0.7);
        
        let playButton = this.add.image(60, 50, 'backT').setScale(0.5);
        playButton.setInteractive();
        playButton.on('pointerup', ()=>{this.scene.start('tuto2')})
        
        let playButton2 = this.add.image(588, 416, 'nextT').setScale(0.5);
        playButton2.setInteractive();
        playButton2.on('pointerup', ()=>{this.scene.start('tuto')})
        
                
    }
    update(){
    }
}