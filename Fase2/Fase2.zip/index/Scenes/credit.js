var BGMC;
export class credit extends Phaser.Scene
{
    constructor()
    {
        super({key: 'credit'})
    }
    init(data){
        BGMC = data.BGMT;
    }
    preload(){
        this.load.image('backTuto', 'assets/fondoTuto.png');
        this.load.image('backTuto2', 'assets/fondoTuto2.png');
        this.load.image('backTuto3', 'assets/fondoTuto3.png');
        this.load.image('backCredit', 'assets/creditos.png');
        this.load.image('PuntT', 'assets/UI/Puntuacion.png');
        this.load.image('WinT', 'assets/UI/GANADOR.png');
        this.load.image('backT2','assets/UI/back2.png')
        this.load.image('nextT','assets/UI/next2.png')
        this.load.audio('BGMM', 'assets/music/menu.mp3');

    }
    create(){
        if (BGMC != null){BGMC.stop();}
        
        this.add.image(324, 228, 'backCredit');
        this.add.image(324, 42, 'OBT').setScale(0.7);
        
        let playButton = this.add.image(60, 50, 'backT2').setScale(0.5);
        playButton.setInteractive();
        playButton.on('pointerup', ()=>{this.scene.start('load')})
        
       
                
    }
    update(){
    }
}